﻿
using System.Text;


namespace MarkelAPI.Common
{
    /// <summary>
    /// Result of any operation
    /// </summary>
    public class Result : IResult
    {
        #region Member Variables

        /// <summary>
        /// Boolean representing the success or failure of the operation
        /// </summary>
        public bool Success { get; set; }

        /// <summary>
        /// This code is used to indicate the number of the error, this means that the errors can be looked up in a table of resources.
        /// </summary>
        public ErrorCodes Code { get; set; }

        /// <summary>
        /// String message relating to the success or failure of the operation
        /// </summary>
        public string Message { get; set; }

        #endregion Member Variables

        #region Constructors

        /// <summary>
        /// Constructor
        /// </summary>
        public Result()
        {
            Code = ErrorCodes.Ok;
        }

        #endregion Constructors

        #region Static Methods

        /// <summary>
        /// Creates a failure result object 
        /// </summary>
        /// <param name="code">This is an enum value indicating the error that has been raised</param>
        /// <param name="message">This is an optional string message that will be set in the result object</param>
        /// <returns>Returns a Result object</returns>
        public static Result Failed(ErrorCodes code, string message = null)
        {
            return new Result
            {
                Success = false,
                Code = code,
                Message = message
            };
        }

        #endregion Static Methods
    }
}
