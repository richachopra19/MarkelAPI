﻿
namespace MarkelAPI.Common
{
    /// <summary>
    /// This interface defines what our Result class must do.
    /// </summary>
    public interface IResult
    {
        #region Member Variables

        /// <summary>
        /// Boolean representing the success or failure of the operation
        /// </summary>
        bool Success { get; set; }

        /// <summary>
        /// This code is used to indicate the number of the error, this means that the errors can be looked up easily with codes.
        /// </summary>
        ErrorCodes Code { get; set; }

        /// <summary>
        /// String message relating to the success or failure of the operation
        /// </summary>
        string Message { get; set; }

        #endregion Member Variables
    }
}
