﻿namespace MarkelAPI.Common
{
    /// <summary>
    /// This extends the Result object with a Success() method and a Failure() method
    /// </summary>
    public static class ResultExtension
    {
        /// <summary>
        /// Take the current result object and ensure that it is set to success, where this is a data object
        /// </summary>
        /// <param name="result">This is the result object we are extending Result where T is an object</param>
        /// <returns>Returns a generic Result object with its data intact</returns>
        public static Result<T> Success<T>(this Result<T> result)
        {
            #region Bounds Checking

            if (result == null)
            {
                return null;
            }

            #endregion Bounds Checking

            result.Success = true;
            result.Message = "Ok";

            return result;
        }

        /// <summary>
        ///Take the current result object and ensure that it is set to failure, where this is a data object
        /// </summary>
        /// <param name="result">This is the result object I am extending</param>
        /// <param name="code">This is a ErrorCodes enum value indicating the error that has been raised</param>
        /// <param name="message">This is an optional string message that will be set in the result object</param>
        /// <returns>Returns a generic Result object</returns>
        public static Result<T> Failure<T>(this Result<T> result, ErrorCodes code, string message = null)
        {
            #region Bounds Checking

            if (result == null)
            {
                return null;
            }

            #endregion Bounds Checking

            result.Success = false;
            result.Code = code;
            result.Message = message;

            return result;
        }
    }
}
