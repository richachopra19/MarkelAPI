﻿namespace MarkelAPI.Common
{
    /// <summary>
    /// An extension of the Result class that has a generic type
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class Result<T> : Result
    {
        #region Member Variables

        /// <summary>
        /// This object can be anything and allows us to pass back the object AND messages about success or failure at the same time and for the Type to be anything
        /// </summary>
        public T Data { get; set; }

        #endregion Member Variables

        #region Constructors

        /// <summary>
        /// Constructor
        /// </summary>
        public Result()
        {
            Code = ErrorCodes.Ok;
        }

        #endregion Constructors

       

    }
}
