﻿namespace MarkelAPI.Common
{
    /// <summary>
    /// This is custom Error codes defined used for any kind of error 
    /// </summary>
    public enum ErrorCodes : int
    {
        /// <summary>
        /// By default it will be zero which means that there is no error code to give
        /// </summary>
        Ok = 0,
        /// <summary>
        /// The claim id was invalid
        /// </summary>
        InvalidClaimId = 1,
        /// <summary>
        /// The claim not found
        /// </summary>
        ClaimNotFound = 2,
        /// <summary>
        /// The company id was invalid
        /// </summary>
        InvalidCompanyId = 3,
        /// <summary>
        /// The claim not found
        /// </summary>
        CompanyNotFound = 4,
        /// <summary>
        /// The claimdto or body is empty
        /// </summary>
        BodyEmpty = 5,
    }
}
