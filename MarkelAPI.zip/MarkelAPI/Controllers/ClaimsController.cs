﻿using MarkelAPI.Common;
using MarkelAPI.Models.Entities;
using MarkelAPI.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace MarkelAPI.Controllers
{
    /// <summary>
    /// This endpoint is responsible for claims or companies data related API requests
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class ClaimsController : Controller
    {
        #region Member variables

        private readonly IClaimService _claimService;
        private readonly ICompanyService _companyService;

        #endregion Member Variables

        #region Constructors

        /// <summary>
        /// Constructor for the ClaimsController
        /// </summary>
        /// <param name="claimService">a concrete class that implements the IClaimService interface</param>
        /// <param name="companyService">a concrete class that implements the ICompanyService interface</param>
        public ClaimsController(IClaimService claimService, ICompanyService companyService)
        {
            _claimService = claimService;
            _companyService = companyService;
        }

        #endregion Constructors

        /// <summary>
        /// This is an endpoint that will give me the details of one claim including property "Age" that that tells us how old the claim is in days
        /// </summary>
        /// <param name="id">this is claim id</param>
        /// <returns> IActionResult </returns>
        [HttpGet]
        [Route("GetClaimById/{id}")]
        public IActionResult GetClaimById(int id)
        {
            #region Bounds Checking and Validation

            if (id < 1)
            {
                return BadRequest(Result.Failed(ErrorCodes.InvalidClaimId,"Claim id is invalid"));
            }
            #endregion Bounds Checking and Validation

            #region Process

            var claimResult = _claimService.GetClaimById(id);
            if (claimResult.Success == false)
            {
                if (claimResult.Code == ErrorCodes.ClaimNotFound)
                {
                    return BadRequest(Result.Failed(ErrorCodes.ClaimNotFound, "Claim not found"));
                }
                return BadRequest(BadRequest(Result.Failed(ErrorCodes.ClaimNotFound, "Claim not found")));
            }

            #endregion Process

            return Ok(claimResult);
        }

        /// <summary>
        /// This is an endpoint that will give me a list of claims for one company
        /// </summary>
        /// <param name="companyId"> int company id for which we are interested to get all claims</param>
        /// <returns>IActionResult</returns>
        [HttpGet]
        [Route("GetClaimsByCompanyId/{companyId}")]
        public IActionResult GetClaimsByCompanyId(int companyId)
        {
            #region Bounds Checking and Validation

            if (companyId < 1)
            {
                return BadRequest(Result.Failed(ErrorCodes.InvalidCompanyId,"Company Id is invalid"));
            }
            #endregion Bounds Checking and Validation

            #region Process

            var claimResult = _claimService.GetClaimsByCompanyId(companyId);
            if (claimResult.Success == false)
            {
                if (claimResult.Code == ErrorCodes.ClaimNotFound)
                {
                    return BadRequest(Result.Failed(ErrorCodes.ClaimNotFound, "Claim not found"));
                }

                return BadRequest(BadRequest(Result.Failed(ErrorCodes.ClaimNotFound, "Claim not found")));
            }

            #endregion Process

            return Ok(claimResult);
        }

        /// <summary>
        /// This is an endpoint that will give me a single company including property "IsActiveInsurancePolicy" that will tell us if the company has an active insurance policy
        /// </summary>
        /// <param name="id">this is id of company</param>
        /// <returns>IActionResult</returns>
        [HttpGet]
        [Route("GetCompanyById/{id}")]
        public IActionResult GetCompanyById(int id)
        {
            #region Bounds Checking and Validation

            if (id < 1)
            {
                return BadRequest(Result.Failed(ErrorCodes.InvalidCompanyId,"Company Id is invalid"));
            }
            #endregion Bounds Checking and Validation

            #region Process

            var companyResult = _companyService.GetCompanyById(id);
            if (companyResult.Success == false)
            {
                if (companyResult.Code == ErrorCodes.CompanyNotFound)
                {
                    return BadRequest(Result.Failed(ErrorCodes.CompanyNotFound, "Company not found"));
                }

                return BadRequest(BadRequest(Result.Failed(ErrorCodes.CompanyNotFound, "Company not found")));
            }

            #endregion Process

            return Ok(companyResult);
        }

        /// <summary>
        /// This is an endpoint that will allow us to update a claim
        /// </summary>
        /// <param name="id">id of claim to be updated</param>
        /// <param name="claimDto">new data object with values to update old one</param>
        /// <returns>IActionResult</returns>

        [HttpPut]
        [Route("Update")]
        public IActionResult Update(int id,[FromBody] ClaimDto claimDto)
        {
            #region Bounds Checking and Validation

            if (id < 1)
            {
                return BadRequest(Result.Failed(ErrorCodes.InvalidClaimId,"Claim id is invalid"));
            }
            if (claimDto == null)
            {
                return BadRequest(Result.Failed(ErrorCodes.BodyEmpty,"Request body is empty"));
            }


            #endregion Bounds Checking and Validation

            var updateResult = _claimService.Update(id, claimDto);
            if (updateResult.Success == false)
            {
                if (updateResult.Code == ErrorCodes.ClaimNotFound)
                {
                    return BadRequest(Result.Failed(ErrorCodes.ClaimNotFound, "Claim not found"));
                }

                return BadRequest(BadRequest(Result.Failed(ErrorCodes.ClaimNotFound, "Claim not found")));
            }
            return Ok(updateResult);
        }
    }
}
