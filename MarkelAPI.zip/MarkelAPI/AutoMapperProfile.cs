﻿using AutoMapper;
using MarkelAPI.Models.Dtos;
using MarkelAPI.Models.Entities;

namespace MarkelAPI
{
    /// <summary>
    /// This is an automapper profile class to show mappings from source to destination used in project
    /// </summary>
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile() 
        {
            CreateMap<Claim, ClaimDto>();
            CreateMap<Company, CompanyDto>();
            CreateMap<ClaimDto, Claim>();
        }
    }
}
