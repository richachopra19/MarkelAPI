﻿using MarkelAPI.Models.Entities;

namespace MarkelAPI.Data
{
    /// <summary>
    /// This is repository interface that is responsible for any kind of data we have for claims / companies
    /// </summary>
    public interface IRepository
    {
        /// <summary>
        /// This is method to fetch all claims
        /// </summary>
        /// <returns>list of object type T where T is Claim</returns>
        public List<Claim> GetClaims();

        /// <summary>
        /// This is method to fetch all companies
        /// </summary>
        /// <returns>list of object type T where T is Company</returns>
        public List<Company> GetCompanies();
    }
}
