﻿using MarkelAPI.Models.Entities;

namespace MarkelAPI.Data
{
    /// <summary>
    /// This is repository class that is responsible for any kind of data we have for claims / companies
    /// </summary>
    public class Repository : IRepository
    {
        /// <summary>
        /// This is method to fetch all claims
        /// </summary>
        /// <returns>list of object type T where T is Claim</returns>
        public List<Claim> GetClaims()
        {
            var claims = new List<Claim>
                {
                new Claim
                {
                    Id = 1,
                    UCR = "UCR1",
                    ClaimDate= DateTime.Parse("2017-04-27"),
                    LossDate= DateTime.Parse("2017-04-27"),
                    AssuredName = "Name1",
                    IncurredLoss = 134567,
                    Closed = true,
                    Type = ClaimType.Definition,
                    Company = new Company
                    {
                        Id= 1,
                        Active= true,
                        Address1   = "Company1_Address1",
                        Address2 = "Company1_Address2",
                        Address3="Company1_Address3",
                        InsuranceEndDate = DateTime.Parse("2018-04-27"),
                        Country = "United Kingdom",
                        Name= "Company1",
                        Postcode    = "EC3M 3AZ"
                    }
                },
                new Claim
                {
                    Id = 2,
                    UCR = "UCR2",
                    ClaimDate= DateTime.Parse("2018-04-27"),
                    LossDate= DateTime.Parse("2018-04-27"),
                    AssuredName = "Name2",
                    IncurredLoss = 15786,
                    Closed = false,
                    Type = ClaimType.Value,
                    Company = new Company
                    {
                        Id= 2,
                        Active= false,
                        Address1 = "Company2_Address1",
                        Address2 = "Company2_Address2",
                        Address3="Company2_Address3",
                        InsuranceEndDate = DateTime.Parse("2025-04-27"),
                        Country = "United Kingdom",
                        Name= "Company2",
                        Postcode = "W!T!UF"
                    }
                },
                new Claim
                {
                    Id = 3,
                    UCR = "UCR3",
                    ClaimDate= DateTime.Parse("2019-04-27"),
                    LossDate= DateTime.Parse("2019-04-27"),
                    AssuredName = "Name3",
                    IncurredLoss = 15786666,
                    Closed = true,
                    Type = ClaimType.Fact,
                    Company = new Company
                    {
                        Id= 2,
                        Active= false,
                        Address1 = "Company2_Address1",
                        Address2 = "Company2_Address2",
                        Address3 ="Company2_Address3",
                        InsuranceEndDate = DateTime.Parse("2025-04-27"),
                        Country = "United Kingdom",
                        Name= "Company2",
                        Postcode    = "W!T!UF"
                    }
                },
                new Claim
                {
                    Id = 4,
                    UCR = "UCR4",
                    ClaimDate= DateTime.Parse("2020-04-27"),
                    LossDate= DateTime.Parse("2020-04-27"),
                    AssuredName = "Name4",
                    IncurredLoss = 188888,
                    Closed = true,
                    Type = ClaimType.Fact,
                    Company = new Company
                    {
                        Id= 3,
                        Active= true,
                        Address1 = "Company3_Address1",
                        Address2 = "Company3_Address2",
                        Address3 ="Company3_Address3",
                        InsuranceEndDate = DateTime.Parse("2019-04-27"),
                        Country = "United Kingdom",
                        Name = "Company3",
                        Postcode  = "W!T!UF"
                    }
                }
                };

            return claims.ToList();
        }

        /// <summary>
        /// This is method to fetch all companies
        /// </summary>
        /// <returns>list of object type T where T is Company</returns>
        public List<Company> GetCompanies()
        {
            var companies = new List<Company>
                {
                new Company
                {
                    Id = 1,
                    Active = true,
                    Address1 = "Company1_Address1",
                    Address2 = "Company1_Address2",
                    Address3 = "Company1_Address3",
                    InsuranceEndDate = DateTime.Parse("2018-04-27"),
                    Country = "United Kingdom",
                    Name = "Company1",
                    Postcode = "EC3M 3AZ"
                },
                 new Company
                    {
                        Id= 2,
                        Active= false,
                        Address1 = "Company2_Address1",
                        Address2 = "Company2_Address2",
                        Address3 ="Company2_Address3",
                        InsuranceEndDate = DateTime.Parse("2025-04-27"),
                        Country = "United Kingdom",
                        Name = "Company2",
                        Postcode = "W!T!UF"

                },
                 new Company
                 {
                        Id= 3,
                        Active= true,
                        Address1 = "Company3_Address1",
                        Address2 = "Company3_Address2",
                        Address3 ="Company3_Address3",
                        InsuranceEndDate = DateTime.Parse("2019-04-27"),
                        Country = "United Kingdom",
                        Name = "Company3",
                        Postcode  = "W!T!UF"
                 }

                };

            return companies.ToList();
        }
    }
}


