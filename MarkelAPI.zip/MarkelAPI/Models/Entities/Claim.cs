﻿namespace MarkelAPI.Models.Entities
{
    /// <summary>
    /// This is claim object class
    /// </summary>
    public class Claim
    {
        /// <summary>
        /// int id of claim
        /// </summary>
        public int Id { get; set; }
        public string UCR { get; set; }
        public DateTime? ClaimDate { get; set; }
        public DateTime? LossDate { get; set; }
        public string AssuredName { get; set; }
        public float IncurredLoss { get; set; }
        public bool Closed { get; set; }
        public Company Company { get; set; }
        public ClaimType Type { get; set; }

    }

    /// <summary>
    /// Enum of claim type
    /// </summary>
    public enum ClaimType
    {
        Fact, Value, Definition
    }
}
