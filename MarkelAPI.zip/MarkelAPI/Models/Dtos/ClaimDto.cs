﻿namespace MarkelAPI.Models.Entities
{
    /// <summary>
    /// This is dto for claim that is sent back as response
    /// </summary>
    public class ClaimDto
    {
        /// <summary>
        /// id of claim
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// UCR
        /// </summary>
        public string UCR { get; set; }

        /// <summary>
        /// ClaimDate
        /// </summary>
        public DateTime? ClaimDate { get; set; }

        /// <summary>
        /// LossDate
        /// </summary>
        public DateTime? LossDate { get; set; }

        /// <summary>
        /// AssuredName
        /// </summary>
        public string AssuredName { get; set; }

        /// <summary>
        /// IncurredLoss
        /// </summary>
        public float IncurredLoss { get; set; }

        /// <summary>
        /// Closed
        /// </summary>
        public bool Closed { get; set; }

        /// <summary>
        /// Company object of type Comapny
        /// </summary>
        public Company Company { get; set; }

        /// <summary>
        /// enum of claim type
        /// </summary>
        public ClaimType Type { get; set; }

        /// <summary>
        /// Gives days of how old claim is
        /// </summary>
        public int Age { get; set; }
    }
}
