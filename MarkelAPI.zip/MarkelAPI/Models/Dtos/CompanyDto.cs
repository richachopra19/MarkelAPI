﻿namespace MarkelAPI.Models.Dtos
{
    /// <summary>
    /// This is dto for company that is sent back as response
    /// </summary>
    public class CompanyDto
    {
        /// <summary>
        /// int id of company
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Name
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Address1
        /// </summary>
        public string Address1 { get; set; }

        /// <summary>
        /// Address2
        /// </summary>
        public string Address2 { get; set; }

        /// <summary>
        /// Address3
        /// </summary>
        public string Address3 { get; set; }

        /// <summary>
        /// Postcode
        /// </summary>
        public string Postcode { get; set; }

        /// <summary>
        /// Country
        /// </summary>

        public string Country { get; set; }

        /// <summary>
        /// Active
        /// </summary>
        public bool Active { get; set; }

        /// <summary>
        /// InsuranceEndDate
        /// </summary>
        public DateTime? InsuranceEndDate { get; set; }

        /// <summary>
        /// If company has active insurance policy
        /// </summary>
        public bool IsActiveInsurancePolicy { get; set; }
    }
}
