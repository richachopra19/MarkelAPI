﻿using MarkelAPI.Common;
using MarkelAPI.Models.Dtos;
using MarkelAPI.Models.Entities;

namespace MarkelAPI.Services.Interfaces
{
    /// <summary>
    /// This is interface that have methods that are responsible to fetch data for companies
    /// </summary>
    public interface ICompanyService
    {
        #region Read

        /// <summary>
        /// This is a method that gives details of one company based on id
        /// </summary>
        /// <param name="id">this is company id</param>
        /// <returns>Result of object T where T is CompanyDto</returns>
        Result<CompanyDto> GetCompanyById(int id);

        #endregion Read
    }
}
