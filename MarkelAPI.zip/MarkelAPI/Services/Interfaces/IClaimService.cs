﻿using MarkelAPI.Common;
using MarkelAPI.Models.Entities;

namespace MarkelAPI.Services.Interfaces
{
    /// <summary>
    /// This is interface that have methods that are responsible to fetch data for claims and companies
    /// </summary>
    public interface IClaimService
    {
        #region Read

        /// <summary>
        /// This is method to get details of one claim including age of claim to tell how old it is
        /// </summary>
        /// <param name="id">this is id of claim for which we want details</param>
        /// <returns>Result object of type T where T is ClaimDto</returns>
        Result<ClaimDto> GetClaimById(int id);

        /// <summary>
        /// This is method to get list of all claims for company
        /// </summary>
        /// <param name="companyId">id of company for which we want claims</param>
        /// <returns>Result object with type T where T is List of Claims</returns>
        Result<List<ClaimDto>> GetClaimsByCompanyId(int companyId);

        #endregion Read

        #region Update

        /// <summary>
        /// This is method to update details of a claim
        /// </summary>
        /// <param name="id">id of claim to update</param>
        /// <param name="claimDto">new object that conatins new data to be updated to</param>
        /// <returns>Result of type T where T is a bool that tells if updation was successful or not</returns>
        Result<bool> Update(int id, ClaimDto claimDto);

        #endregion Update
    }
}
