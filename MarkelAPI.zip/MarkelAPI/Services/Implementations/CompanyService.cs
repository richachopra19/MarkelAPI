﻿using AutoMapper;
using MarkelAPI.Common;
using MarkelAPI.Data;
using MarkelAPI.Models.Dtos;
using MarkelAPI.Models.Entities;
using MarkelAPI.Services.Interfaces;
using System.Security.Claims;

namespace MarkelAPI.Services.Implementations
{
    /// <summary>
    /// the concrete implementation of the CompanyServic
    /// </summary>
    public class CompanyService : ICompanyService
    {
        #region Member Variables

        private readonly IRepository _repository;
        private readonly IMapper _mapper;

        #endregion Member Variables

        #region Constructors

        /// <summary>
        /// Create my Service
        /// </summary>
        /// <param name="repository">a concrete class that implements the IClaimRepository interface object</param>
        public CompanyService(IRepository repository, IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }

        #endregion Constructors

        #region Read

        /// <summary>
        /// This is a method that gives details of one company based on id
        /// </summary>
        /// <param name="id">this is company id</param>
        /// <returns>Result of object T where T is CompanyDto</returns>
        public Result<CompanyDto> GetCompanyById(int id)
        {
            #region Initialize

            var result = new Result<CompanyDto>
            {
                Data = new CompanyDto()
            };

            #endregion Initialize

            #region Bounds Checking

            if (id < 1)
            {
                return result.Failure(ErrorCodes.InvalidCompanyId);
            }

            #endregion Bounds Checking

            #region Fetch Data

            var allCompanies = _repository.GetCompanies();
            if (allCompanies == null)
            {
                return result.Failure(ErrorCodes.CompanyNotFound);
            }
            var company = allCompanies.FirstOrDefault(x => x.Id == id);
            if (company == null)
            {
                return result.Failure(ErrorCodes.CompanyNotFound);
            }

            #endregion Fetch Data

            #region Process

            //Automapper to map data
            _mapper.Map(company, result.Data);
            var today = DateTime.Now;
            result.Data.IsActiveInsurancePolicy = result.Data.Active && result.Data.InsuranceEndDate != null && result.Data.InsuranceEndDate > today;

            #endregion Process

            return result.Success();
        }

        #endregion Read
    }
}
