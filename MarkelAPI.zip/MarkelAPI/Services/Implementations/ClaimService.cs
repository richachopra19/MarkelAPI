﻿using AutoMapper;
using MarkelAPI.Data;
using MarkelAPI.Models.Entities;
using MarkelAPI.Services.Interfaces;
using MarkelAPI.Common;
using System.Security.Claims;

namespace MarkelAPI.Services.Implementations
{
    /// <summary>
    /// the concrete implementation of the ClaimService
    /// </summary>
    public class ClaimService : IClaimService
    {
        #region Member Variables

        private readonly IRepository _repository;
        private readonly IMapper _mapper;

        #endregion Member Variables

        #region Constructor

        /// <summary>
        /// Create my Service
        /// </summary>
        /// <param name="repository">a concrete class that implements the IClaimRepository interface object</param>
        public ClaimService(IRepository repository, IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }

        #endregion Constructor

        #region Read

        /// <summary>
        /// This is method to get details of one claim including age of claim to tell how old it is
        /// </summary>
        /// <param name="id">this is id of claim for which we want details</param>
        /// <returns>Result object of type T where T is ClaimDto</returns>
        public Result<ClaimDto> GetClaimById(int id)
        {
            #region Initialize

            var result = new Result<ClaimDto>
            {
                Data = new ClaimDto()
            };

            #endregion Initialize

            #region Bounds Checking

            if (id < 1)
            {
                return result.Failure(ErrorCodes.InvalidClaimId);
            }

            #endregion Bounds Checking

            #region Fetch Data

            var allClaims = _repository.GetClaims();
            if (allClaims == null)
            {
                return result.Failure(ErrorCodes.ClaimNotFound);
            }
            var claim = allClaims.FirstOrDefault(x => x.Id == id);
            if (claim == null)
            {
                return result.Failure(ErrorCodes.ClaimNotFound);
            }
            #endregion Fetch Data

            #region Process

            //Automapper to map src to destination
            _mapper.Map(claim, result.Data);
            result.Data.Age = result.Data.ClaimDate != null ? (DateTime.Now.Date - result.Data.ClaimDate.Value.Date).Days : 0;

            #endregion Process
                
            return result.Success();
        }

        /// <summary>
        /// This is method to get list of all claims for company
        /// </summary>
        /// <param name="companyId">id of company for which we want claims</param>
        /// <returns>Result object with type T where T is List of Claims</returns>
        public Result<List<ClaimDto>> GetClaimsByCompanyId(int companyId)
        {
            #region Initialize

            var result = new Result<List<ClaimDto>>
            {
                Data = new List<ClaimDto>()
            };

            #endregion Initialize

            #region Bounds Checking

            if (companyId < 1)
            {
                return result.Failure(ErrorCodes.InvalidCompanyId); ;
            }

            #endregion Bounds Checking

            #region Fetch Data

            var allClaims = _repository.GetClaims();
            if (allClaims == null)
            {
                return result.Failure(ErrorCodes.ClaimNotFound);
            }
            var claimsForCompany = allClaims.Where(x => x.Company.Id == companyId).ToList();
            if (claimsForCompany.Count == 0)
            {
                return result.Failure(ErrorCodes.ClaimNotFound);
            }

            #endregion Fetch Data

            #region Process

            //Automapper to map src to destination
            _mapper.Map(claimsForCompany, result.Data);
            foreach (var claim in result.Data)
            {
                claim.Age = claim.ClaimDate != null ? (DateTime.Now.Date - claim.ClaimDate.Value.Date).Days : 0;
            }

            #endregion Process

            return result.Success(); ;
        }

        #endregion Read

        #region Update

        /// <summary>
        /// This is method to update details of a claim
        /// </summary>
        /// <param name="id">id of claim to update</param>
        /// <param name="claimDto">new object that conatins new data to be updated to</param>
        /// <returns>Result of type T where T is a bool that tells if updation was successful or not</returns>
        public Result<bool> Update(int id, ClaimDto claimDto)
        {

            #region Initialize

            var result = new Result<bool>
            {
                Data = false
            };

            #endregion Initialize

            #region Fetch Data

            var allClaims = _repository.GetClaims();
            if (allClaims == null)
            {
                return result.Failure(ErrorCodes.ClaimNotFound);
            }
            var claim = allClaims.FirstOrDefault(x => x.Id == id);
            if (claim == null)
            {
                return result.Failure(ErrorCodes.ClaimNotFound);
            }

            #endregion Fetch Data

            #region Process

            _mapper.Map(claimDto, claim);

            #endregion Process

            result.Data = true;
            result.Message = "Successfully updated";

            return result.Success();
        }

        #endregion Update

    }
}
