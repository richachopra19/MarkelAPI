﻿
using MarkelAPI.Common;
using MarkelAPI.Models.Dtos;
using MarkelAPI.Models.Entities;
using MarkelAPI.Services.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace MarkelAPITest.Controllers.Claims
{
    [TestFixture]
    public class UpdateTests
    {
        #region Member Variables

        private Mock<IClaimService> _claimService;
        private Mock<ICompanyService> _companyService;
        private MarkelAPI.Controllers.ClaimsController _controller;


        #endregion Member Variables

        #region Setup

        /// <summary>
        /// Create dependencies and the system under test
        /// </summary>
        [SetUp]
        public void CreateDependencies()
        {
            _claimService = new Mock<IClaimService>();
            _companyService= new Mock<ICompanyService>();
            _controller = new MarkelAPI.Controllers.ClaimsController(_claimService.Object, _companyService.Object);
        }

        #endregion Setup

        /// <summary>
        /// When claim id is invalid
        /// </summary>
        [Test]
        public void WhenClaimIdIsInvalid()
        {
            // Arrange

            #region Objects

            var claimId = 0;
            ClaimDto claimDto = new ClaimDto();

            #endregion Objects

            // Act

            var actionResult = _controller.Update(claimId, claimDto);


            // Assert
            var result = actionResult as BadRequestObjectResult;
            Assert.That(result?.StatusCode, Is.EqualTo(StatusCodes.Status400BadRequest));
            var value = result?.Value as Result;
            Assert.IsNotNull(value);
            Assert.IsFalse(value.Success);
            Assert.That(value.Code, Is.EqualTo(ErrorCodes.InvalidClaimId));

        }

        /// <summary>
        /// When claim dto is empty
        /// </summary>
        [Test]
        public void WhenClaimDtoIsInvalid()
        {
            // Arrange

            #region Objects

            var claimId = 1;
            ClaimDto claimDto = null;

            #endregion Objects

            // Act

            var actionResult = _controller.Update(claimId, claimDto);


            // Assert
            var result = actionResult as BadRequestObjectResult;
            Assert.That(result?.StatusCode, Is.EqualTo(StatusCodes.Status400BadRequest));
            var value = result?.Value as Result;
            Assert.IsNotNull(value);
            Assert.IsFalse(value.Success);
            Assert.That(value.Code, Is.EqualTo(ErrorCodes.BodyEmpty));

        }

        /// <summary>
        /// When update result is false
        /// </summary>
        [Test]
        public void WhenUpdateResultIsFalse()
        {
            // Arrange

            #region Objects

            var claimId = 1;
            ClaimDto claimDto = new ClaimDto();
            var internalResult = new Result<bool>
            {
                Success = false,
                Message = "Claim not found",
                Code = ErrorCodes.ClaimNotFound
            };

            #endregion Objects

            #region Behaviours

            _claimService.Setup(e => e.Update(It.IsAny<int>(), It.IsAny<ClaimDto>()))
                         .Returns(internalResult);

            #endregion Behaviours

            // Act

            var actionResult = _controller.Update(claimId, claimDto);


            // Assert
            var result = actionResult as BadRequestObjectResult;
            Assert.That(result?.StatusCode, Is.EqualTo(StatusCodes.Status400BadRequest));
            var value = result?.Value as Result;
            Assert.IsNotNull(value);
            Assert.IsFalse(value.Success);
            Assert.That(value.Code, Is.EqualTo(ErrorCodes.ClaimNotFound));
            _claimService.Verify(e => e.Update(It.IsAny<int>(), It.IsAny<ClaimDto>()), Times.Once);

        }

        /// <summary>
        /// When Claim result is false
        /// </summary>
        [Test]
        public void WhenClaimIdNotFound()
        {
            // Arrange

            #region Objects

            var claimId = 4;
            ClaimDto claimDto = new ClaimDto();
            var internalResult = new Result<bool>
            {
                Success = false,
                Message = "Claim not found",
                Code = ErrorCodes.ClaimNotFound
            };

            #endregion Objects

            #region Behaviours

            _claimService.Setup(e => e.Update(It.IsAny<int>(), It.IsAny<ClaimDto>()))
                         .Returns(internalResult);

            #endregion Behaviours

            // Act

            var actionResult = _controller.Update(claimId, claimDto);


            // Assert
            var result = actionResult as BadRequestObjectResult;
            Assert.That(result?.StatusCode, Is.EqualTo(StatusCodes.Status400BadRequest));
            var value = result?.Value as Result;
            Assert.IsNotNull(value);
            Assert.IsFalse(value.Success);
            Assert.That(value.Code, Is.EqualTo(ErrorCodes.ClaimNotFound));
            _claimService.Verify(e => e.Update(It.IsAny<int>(), It.IsAny<ClaimDto>()), Times.Once);

        }

        /// <summary>
        /// When all ok
        /// </summary>
        [Test]
        public void WhenAllOk()
        {
            // Arrange

            #region Objects

            var claimId = 2;
            ClaimDto claimDto = new ClaimDto();
            var internalResult = new Result<bool>
            {
                Success = true,
                Message = "",
            };

            #endregion Objects

            #region Behaviours

            _claimService.Setup(e => e.Update(It.IsAny<int>(), It.IsAny<ClaimDto>()))
                        .Returns(internalResult);

            #endregion Behaviours

            // Act

            var actionResult = _controller.Update(claimId, claimDto);


            // Assert
            var result = actionResult as OkObjectResult;
            Assert.That(result?.StatusCode, Is.EqualTo(StatusCodes.Status200OK));
            var value = result?.Value as Result;
            Assert.IsNotNull(value);
            Assert.IsTrue(value.Success);
            _claimService.Verify(e => e.Update(It.IsAny<int>(), It.IsAny<ClaimDto>()), Times.Once);

        }
    }
}
