﻿

using MarkelAPI.Common;
using MarkelAPI.Models.Entities;
using MarkelAPI.Services.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace MarkelAPITest.Controllers.Claims
{
    [TestFixture]
    public class GetClaimsByCompanyIdTests
    {
        #region Member Variables

        private Mock<IClaimService> _claimService;
        private Mock<ICompanyService> _companyService;
        private MarkelAPI.Controllers.ClaimsController _controller;


        #endregion Member Variables

        #region Setup

        /// <summary>
        /// Create dependencies and the system under test
        /// </summary>
        [SetUp]
        public void CreateDependencies()
        {
            _claimService = new Mock<IClaimService>();
            _companyService= new Mock<ICompanyService>();
            _controller = new MarkelAPI.Controllers.ClaimsController(_claimService.Object, _companyService.Object);
        }

        #endregion Setup

        /// <summary>
        /// When claim id is invalid
        /// </summary>
        [Test]
        public void WhenCompanyIdIsInvalid()
        {
            // Arrange

            #region Objects

            var companyId = 0;

            #endregion Objects

            // Act

            var actionResult = _controller.GetClaimsByCompanyId(companyId);


            // Assert
            var result = actionResult as BadRequestObjectResult;
            Assert.That(result?.StatusCode, Is.EqualTo(StatusCodes.Status400BadRequest));
            var value = result?.Value as Result;
            Assert.IsNotNull(value);
            Assert.IsFalse(value.Success);
            Assert.That(value.Code, Is.EqualTo(ErrorCodes.InvalidCompanyId));

        }

        /// <summary>
        /// When claim result is false
        /// </summary>
        [Test]
        public void WhenClaimResultIsFalse()
        {
            // Arrange

            #region Objects

            var companyId = 1;
            var internalResult = new Result<List<ClaimDto>>
            {
                Success = false,
                Message = "Claim not found",
                Code = ErrorCodes.ClaimNotFound
            };

            #endregion Objects

            #region Behaviours

            _claimService.Setup(e => e.GetClaimsByCompanyId(It.IsAny<int>()))
                         .Returns(internalResult);

            #endregion Behaviours

            // Act

            var actionResult = _controller.GetClaimsByCompanyId(companyId);


            // Assert
            var result = actionResult as BadRequestObjectResult;
            Assert.That(result?.StatusCode, Is.EqualTo(StatusCodes.Status400BadRequest));
            var value = result?.Value as Result;
            Assert.IsNotNull(value);
            Assert.IsFalse(value.Success);
            Assert.That(value.Code, Is.EqualTo(ErrorCodes.ClaimNotFound));
            _claimService.Verify(e => e.GetClaimsByCompanyId(It.IsAny<int>()), Times.Once);

        }

        /// <summary>
        /// When claim result is false
        /// </summary>
        [Test]
        public void WhenClaimIdNotFound()
        {
            // Arrange

            #region Objects

            var companyId = 4;
            var internalResult = new Result<List<ClaimDto>>
            {
                Success = false,
                Message = "Claim not found",
                Code = ErrorCodes.ClaimNotFound
            };

            #endregion Objects

            #region Behaviours

            _claimService.Setup(e => e.GetClaimsByCompanyId(It.IsAny<int>()))
                         .Returns(internalResult);

            #endregion Behaviours

            // Act

            var actionResult = _controller.GetClaimsByCompanyId(companyId);


            // Assert
            var result = actionResult as BadRequestObjectResult;
            Assert.That(result?.StatusCode, Is.EqualTo(StatusCodes.Status400BadRequest));
            var value = result?.Value as Result;
            Assert.IsNotNull(value);
            Assert.IsFalse(value.Success);
            Assert.That(value.Code, Is.EqualTo(ErrorCodes.ClaimNotFound));
            _claimService.Verify(e => e.GetClaimsByCompanyId(It.IsAny<int>()), Times.Once);

        }

        /// <summary>
        /// When all ok
        /// </summary>
        [Test]
        public void WhenAllOk()
        {
            // Arrange

            #region Objects

            var companyId = 1;
            var internalResult = new Result<List<ClaimDto>>
            {
                Success = true,
                Message = "",
            };

            #endregion Objects

            #region Behaviours

            _claimService.Setup(e => e.GetClaimsByCompanyId(It.IsAny<int>()))
                         .Returns(internalResult);

            #endregion Behaviours

            // Act

            var actionResult = _controller.GetClaimsByCompanyId(companyId);


            // Assert
            var result = actionResult as OkObjectResult;
            Assert.That(result?.StatusCode, Is.EqualTo(StatusCodes.Status200OK));
            var value = result?.Value as Result;
            Assert.IsNotNull(value);
            Assert.IsTrue(value.Success);
            _claimService.Verify(e => e.GetClaimsByCompanyId(It.IsAny<int>()), Times.Once);

        }

    }
}
