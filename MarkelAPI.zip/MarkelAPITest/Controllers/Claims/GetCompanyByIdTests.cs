﻿
using MarkelAPI.Common;
using MarkelAPI.Models.Dtos;
using MarkelAPI.Models.Entities;
using MarkelAPI.Services.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace MarkelAPITest.Controllers.Claims
{
    [TestFixture]
    public class GetCompanyByIdTests
    {
        #region Member Variables

        private Mock<IClaimService> _claimService;
        private Mock<ICompanyService> _companyService;
        private MarkelAPI.Controllers.ClaimsController _controller;


        #endregion Member Variables

        #region Setup

        /// <summary>
        /// Create dependencies and the system under test
        /// </summary>
        [SetUp]
        public void CreateDependencies()
        {
            _claimService = new Mock<IClaimService>();
            _companyService= new Mock<ICompanyService>();
            _controller = new MarkelAPI.Controllers.ClaimsController(_claimService.Object, _companyService.Object);
        }

        #endregion Setup

        /// <summary>
        /// When company id is invalid
        /// </summary>
        [Test]
        public void WhenCompanyIdIsInvalid()
        {
            // Arrange

            #region Objects

            var companyId = 0;

            #endregion Objects

            // Act

            var actionResult = _controller.GetCompanyById(companyId);


            // Assert
            var result = actionResult as BadRequestObjectResult;
            Assert.That(result?.StatusCode, Is.EqualTo(StatusCodes.Status400BadRequest));
            var value = result?.Value as Result;
            Assert.IsNotNull(value);
            Assert.IsFalse(value.Success);
            Assert.That(value.Code, Is.EqualTo(ErrorCodes.InvalidCompanyId));

        }

        /// <summary>
        /// When company result is false
        /// </summary>
        [Test]
        public void WhenCompanyResultIsFalse()
        {
            // Arrange

            #region Objects

            var companyId = 1;
            var internalResult = new Result<CompanyDto>
            {
                Success = false,
                Message = "Company not found",
                Code = ErrorCodes.CompanyNotFound
            };

            #endregion Objects

            #region Behaviours

            _companyService.Setup(e => e.GetCompanyById(It.IsAny<int>()))
                         .Returns(internalResult);

            #endregion Behaviours

            // Act

            var actionResult = _controller.GetCompanyById(companyId);


            // Assert
            var result = actionResult as BadRequestObjectResult;
            Assert.That(result?.StatusCode, Is.EqualTo(StatusCodes.Status400BadRequest));
            var value = result?.Value as Result;
            Assert.IsNotNull(value);
            Assert.IsFalse(value.Success);
            Assert.That(value.Code, Is.EqualTo(ErrorCodes.CompanyNotFound));
            _companyService.Verify(e => e.GetCompanyById(It.IsAny<int>()), Times.Once);

        }

        /// <summary>
        /// When company result is false
        /// </summary>
        [Test]
        public void WhenCompanyIdNotFound()
        {
            // Arrange

            #region Objects

            var companyId = 4;
            var internalResult = new Result<CompanyDto>
            {
                Success = false,
                Message = "Company not found",
                Code = ErrorCodes.CompanyNotFound
            };

            #endregion Objects

            #region Behaviours

            _companyService.Setup(e => e.GetCompanyById(It.IsAny<int>()))
                           .Returns(internalResult);

            #endregion Behaviours

            // Act

            var actionResult = _controller.GetCompanyById(companyId);


            // Assert
            var result = actionResult as BadRequestObjectResult;
            Assert.That(result?.StatusCode, Is.EqualTo(StatusCodes.Status400BadRequest));
            var value = result?.Value as Result;
            Assert.IsNotNull(value);
            Assert.IsFalse(value.Success);
            Assert.That(value.Code, Is.EqualTo(ErrorCodes.CompanyNotFound));
            _companyService.Verify(e => e.GetCompanyById(It.IsAny<int>()), Times.Once);

        }

        /// <summary>
        /// When all ok
        /// </summary>
        [Test]
        public void WhenAllOk()
        {
            // Arrange

            #region Objects

            var companyId = 3;
            var internalResult = new Result<CompanyDto>
            {
                Success = true,
                Message = "",
            };

            #endregion Objects

            #region Behaviours

            _companyService.Setup(e => e.GetCompanyById(It.IsAny<int>()))
                           .Returns(internalResult);

            #endregion Behaviours

            // Act

            var actionResult = _controller.GetCompanyById(companyId);


            // Assert
            var result = actionResult as OkObjectResult;
            Assert.That(result?.StatusCode, Is.EqualTo(StatusCodes.Status200OK));
            var value = result?.Value as Result;
            Assert.IsNotNull(value);
            Assert.IsTrue(value.Success);
            _companyService.Verify(e => e.GetCompanyById(It.IsAny<int>()), Times.Once);

        }
    }
}
